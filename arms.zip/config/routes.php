<?php
$routes = [
    '' => 'HomeController@index',
    'home' => 'HomeController@index',
    // tambahkan route lainnya di sini
    'assets' => 'AssetController@index',
    // Add other routes as needed
];
?>
