<?php
return [
    'app_name' => 'Asset and Request Management System',
    'base_url' => 'http://localhost/arms',
    'debug' => true,
];
?>