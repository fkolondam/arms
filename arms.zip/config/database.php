<?php
return [
    'host' => '127.0.0.1',
    'database' => 'arms',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => '',
];
?>